# Anonymous materials

The manuscript is a critical narrative survey with a bounded thirteen-study documentary audit. The data are source-linked descriptions, not new model experiments or human annotation. The CSV, codebook, source manifests, and notes record inspected passages and uncertainties. Full source-paper PDFs are not redistributed. No field-wide prevalence estimate is supported.

For the anonymous source package, compile main.tex using pdfLaTeX/BibTeX or latexmk -pdf main.tex. The optional public identity wrapper is intentionally excluded. The separate supplement contains the detailed audit records. Original figures are preserved unchanged and their visual-design sources are cited in Appendix A.
